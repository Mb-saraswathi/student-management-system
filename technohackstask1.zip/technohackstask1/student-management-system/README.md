# Student Management System

A Complete Professional Full Stack CRUD Application using Node.js, Express, MySQL, and Vanilla JavaScript with Bootstrap 5.

## Technologies Used
*   **Frontend**: HTML5, CSS3, Vanilla JS, Bootstrap 5
*   **Backend**: Node.js, Express.js
*   **Database**: MySQL

## Project Setup & Running Instructions

Follow these step-by-step instructions to get the project running on your local machine.

### 1. Database Setup

First, you need to create the database and the table in your MySQL environment.
Open your MySQL console or a tool like phpMyAdmin/MySQL Workbench and run the following SQL queries:

```sql
CREATE DATABASE student_management;

USE student_management;

CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL
);
```

### 2. MySQL Connection Setup

In the project folder, open `server/db.js`.
Update the database connection details to match your local MySQL credentials:

```javascript
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root', // <-- Replace with your MySQL username
  password: '', // <-- Replace with your MySQL password
  database: 'student_management',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
```

### 3. Install Backend Dependencies

Open your terminal, navigate to the project directory containing the `package.json` file, and run:

```bash
npm install
```

### 4. Run the Backend Server

Start the Node.js Express server by running:

```bash
npm start
```

Alternatively, you can run `node server/server.js`. The server will start on `http://localhost:3000`.

### 5. Run the Frontend

The frontend consists of static files (`index.html`, `style.css`, `script.js`). 
You can simply open `client/index.html` directly in your web browser. 
For the best experience, use a local server like the "Live Server" extension in VS Code.

## Application Features
*   **Create**: Add new student records securely.
*   **Read**: Real-time fetching and displaying of student records.
*   **Update**: Edit and update existing student data in-place.
*   **Delete**: Confirmations on deleting student records.
*   **Validations**: HTML5 form validation handled elegantly with Bootstrap.
*   **Alerts**: Dynamic success, error, and delete alert banners.
