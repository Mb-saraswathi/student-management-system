// Base URL for the backend API
const API_URL = 'http://localhost:3000/students';

// DOM Elements
const studentForm = document.getElementById('studentForm');
const studentsTable = document.getElementById('studentsTable');
const studentList = document.getElementById('studentList');
const formTitle = document.getElementById('formTitle');
const submitBtn = document.getElementById('submitBtn');
const cancelBtn = document.getElementById('cancelBtn');
const totalStudents = document.getElementById('totalStudents');
const alertContainer = document.getElementById('alertContainer');

// State flags
let isEditing = false;

// Event Listeners
document.addEventListener('DOMContentLoaded', fetchStudents);
studentForm.addEventListener('submit', handleFormSubmit);
cancelBtn.addEventListener('click', resetForm);

/**
 * Fetch all students from the REST API
 */
async function fetchStudents() {
    try {
        const response = await fetch(API_URL);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const students = await response.json();
        renderStudents(students);
    } catch (error) {
        console.error('Error fetching students:', error);
        showAlert('Failed to load students. Please ensure the backend server is running.', 'danger');
        studentList.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4 text-danger">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> Error loading data
                </td>
            </tr>`;
    }
}

/**
 * Render the students array into the HTML table
 */
function renderStudents(students) {
    if (students.length === 0) {
        studentList.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4 text-muted">
                    No students found. Add a new student to get started.
                </td>
            </tr>`;
        totalStudents.textContent = `Total: 0`;
        return;
    }

    totalStudents.textContent = `Total: ${students.length}`;
    studentList.innerHTML = '';

    students.forEach((student) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="fw-semibold">#${student.id}</td>
            <td>
                <div class="d-flex align-items-center">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                        ${student.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                        <h6 class="mb-0">${student.name}</h6>
                    </div>
                </div>
            </td>
            <td><a href="mailto:${student.email}" class="text-decoration-none">${student.email}</a></td>
            <td><span class="badge bg-info text-dark">${student.course}</span></td>
            <td>${student.phone}</td>
            <td class="text-center">
                <button class="btn btn-sm btn-outline-primary btn-action me-1" onclick="editStudent(${student.id}, '${student.name.replace(/'/g, "\\'")}', '${student.email}', '${student.course}', '${student.phone}')" title="Edit">
                    <i class="bi bi-pencil-fill"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger btn-action" onclick="deleteStudent(${student.id})" title="Delete">
                    <i class="bi bi-trash-fill"></i>
                </button>
            </td>
        `;
        studentList.appendChild(tr);
    });
}

/**
 * Handle Add/Update form submission
 */
async function handleFormSubmit(e) {
    e.preventDefault();
    
    // Form validation check
    if (!studentForm.checkValidity()) {
        e.stopPropagation();
        studentForm.classList.add('was-validated');
        return;
    }

    const studentId = document.getElementById('studentId').value;
    const studentData = {
        name: document.getElementById('name').value.trim(),
        email: document.getElementById('email').value.trim(),
        course: document.getElementById('course').value.trim(),
        phone: document.getElementById('phone').value.trim()
    };

    try {
        let response;
        if (isEditing) {
            // Update existing student (PUT)
            response = await fetch(`${API_URL}/${studentId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(studentData)
            });
        } else {
            // Add new student (POST)
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(studentData)
            });
        }

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || 'Failed to save student');
        }

        showAlert(result.message, 'success');
        resetForm();
        fetchStudents();
    } catch (error) {
        console.error('Error saving student:', error);
        showAlert(error.message, 'danger');
    }
}

/**
 * Setup form for editing a specific student
 */
function editStudent(id, name, email, course, phone) {
    isEditing = true;
    
    // Populate form fields
    document.getElementById('studentId').value = id;
    document.getElementById('name').value = name;
    document.getElementById('email').value = email;
    document.getElementById('course').value = course;
    document.getElementById('phone').value = phone;
    
    // Update UI
    formTitle.textContent = 'Edit Student Details';
    submitBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Update Student';
    submitBtn.classList.replace('btn-primary', 'btn-success');
    cancelBtn.classList.remove('d-none');
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Delete a student record
 */
async function deleteStudent(id) {
    if (confirm('Are you sure you want to delete this student record? This action cannot be undone.')) {
        try {
            const response = await fetch(`${API_URL}/${id}`, {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.error || 'Failed to delete student');
            }
            
            showAlert(result.message, 'warning');
            fetchStudents();
            
            // If the deleted user is currently being edited, reset form
            if (isEditing && document.getElementById('studentId').value == id) {
                resetForm();
            }
        } catch (error) {
            console.error('Error deleting student:', error);
            showAlert(error.message, 'danger');
        }
    }
}

/**
 * Reset the form back to initial 'Add' state
 */
function resetForm() {
    isEditing = false;
    studentForm.reset();
    studentForm.classList.remove('was-validated');
    document.getElementById('studentId').value = '';
    
    formTitle.textContent = 'Add New Student';
    submitBtn.innerHTML = '<i class="bi bi-save me-1"></i> Save Student';
    submitBtn.classList.replace('btn-success', 'btn-primary');
    cancelBtn.classList.add('d-none');
}

/**
 * Display Bootstrap Alert messages dynamically
 */
function showAlert(message, type) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi ${type === 'success' ? 'bi-check-circle-fill' : type === 'warning' ? 'bi-exclamation-triangle-fill' : 'bi-x-circle-fill'} me-2"></i>
            <strong>${type === 'success' ? 'Success!' : type === 'warning' ? 'Deleted!' : 'Error!'}</strong> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    alertContainer.innerHTML = alertHtml;
    
    // Auto remove alert after 5 seconds
    setTimeout(() => {
        const activeAlert = document.querySelector('.alert');
        if (activeAlert) {
            const bsAlert = new bootstrap.Alert(activeAlert);
            bsAlert.close();
        }
    }, 5000);
}
