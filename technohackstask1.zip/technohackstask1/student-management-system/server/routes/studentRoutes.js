const express = require('express');
const router = express.Router();
const db = require('../db');

// Create a new student (POST /students)
router.post('/', async (req, res) => {
    try {
        const { name, email, course, phone } = req.body;
        
        if (!name || !email || !course || !phone) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const query = 'INSERT INTO students (name, email, course, phone) VALUES (?, ?, ?, ?)';
        const [result] = await db.execute(query, [name, email, course, phone]);
        
        res.status(201).json({ id: result.insertId, name, email, course, phone, message: 'Student created successfully' });
    } catch (error) {
        console.error('Error creating student:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get all students (GET /students)
router.get('/', async (req, res) => {
    try {
        const query = 'SELECT * FROM students';
        const [rows] = await db.execute(query);
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update a student (PUT /students/:id)
router.put('/:id', async (req, res) => {
    try {
        const studentId = req.params.id;
        const { name, email, course, phone } = req.body;
        
        if (!name || !email || !course || !phone) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const query = 'UPDATE students SET name = ?, email = ?, course = ?, phone = ? WHERE id = ?';
        const [result] = await db.execute(query, [name, email, course, phone, studentId]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        res.status(200).json({ id: studentId, name, email, course, phone, message: 'Student updated successfully' });
    } catch (error) {
        console.error('Error updating student:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Delete a student (DELETE /students/:id)
router.delete('/:id', async (req, res) => {
    try {
        const studentId = req.params.id;
        
        const query = 'DELETE FROM students WHERE id = ?';
        const [result] = await db.execute(query, [studentId]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        res.status(200).json({ message: 'Student deleted successfully' });
    } catch (error) {
        console.error('Error deleting student:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
