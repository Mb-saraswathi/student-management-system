const mysql = require('mysql2');

// Database connection configuration
// Make sure to replace with your actual MySQL credentials
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root', // Replace with your MySQL username
  password: 'honey7', // Replace with your MySQL password
  database: 'student_management',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const promisePool = pool.promise();

module.exports = promisePool;
